The starting point is labeled A

The termination point is labeled B